import { LocalizedString } from './types';

export const navLabels: {
  programs: LocalizedString;
  centres: LocalizedString;
  coaches: LocalizedString;
  bookTrial: LocalizedString;
  bookTrialMobile: LocalizedString;
} = {
  programs: { en: "Programs", mr: "कार्यक्रम" },
  centres: { en: "Centres", mr: "केंद्रे" },
  coaches: { en: "Coaches", mr: "प्रशिक्षक" },
  bookTrial: { en: "Book Trial", mr: "ट्रायल बुक करा" },
  bookTrialMobile: { en: "Book a Trial", mr: "ट्रायल बुक करा" },
};
